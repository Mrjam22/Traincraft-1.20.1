/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.impl.sync;

import net.minecraft.core.registries.BuiltInRegistries;
import org.jetbrains.annotations.ApiStatus;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
import org.quiltmc.qsl.registry.impl.sync.mod_protocol.ModProtocolImpl;
import org.quiltmc.qsl.registry.impl.sync.registry.SynchronizedRegistry;
import org.quiltmc.qsl.registry.impl.sync.server.ServerRegistrySync;

@ApiStatus.Internal
public class RegistrySyncInitializer implements ModInitializer {
	@Override
	public void onInitialize(ModContainer mod) {
		ServerRegistrySync.readConfig();
		ModProtocolImpl.loadVersions();

		SynchronizedRegistry.markForSync(
				BuiltInRegistries.BLOCK,
				BuiltInRegistries.BLOCK_ENTITY_TYPE,
				BuiltInRegistries.CAT_VARIANT,
				BuiltInRegistries.COMMAND_ARGUMENT_TYPE,
				BuiltInRegistries.ENCHANTMENT,
				BuiltInRegistries.ENTITY_TYPE,
				BuiltInRegistries.FLUID,
				BuiltInRegistries.FROG_VARIANT,
				BuiltInRegistries.GAME_EVENT,
				BuiltInRegistries.ITEM,
				BuiltInRegistries.PAINTING_VARIANT,
				BuiltInRegistries.PARTICLE_TYPE,
				BuiltInRegistries.MENU,
				BuiltInRegistries.SOUND_EVENT,
				BuiltInRegistries.STAT_TYPE,
				BuiltInRegistries.MOB_EFFECT,
				BuiltInRegistries.VILLAGER_TYPE,
				BuiltInRegistries.VILLAGER_PROFESSION
		);
	}
}
