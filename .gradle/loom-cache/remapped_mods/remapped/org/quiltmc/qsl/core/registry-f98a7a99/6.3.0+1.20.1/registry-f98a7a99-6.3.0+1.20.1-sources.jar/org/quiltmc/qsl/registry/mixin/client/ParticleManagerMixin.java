/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.mixin.client;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.core.registries.BuiltInRegistries;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.registry.impl.sync.client.RebuildableIdModelHolder;
import org.quiltmc.qsl.registry.impl.sync.registry.SynchronizedInt2ObjectMap;

@ClientOnly
@Mixin(ParticleEngine.class)
public class ParticleManagerMixin implements RebuildableIdModelHolder {
	@Mutable
	@Final
	@Shadow
	private Int2ObjectMap<ParticleProvider<?>> factories;

	@Inject(method = "<init>", at = @At("RETURN"))
	private void quilt$onInit(ClientLevel clientWorld, TextureManager textureManager, CallbackInfo ci) {
		this.factories = new SynchronizedInt2ObjectMap<>(BuiltInRegistries.PARTICLE_TYPE, this.factories);
	}

	@Override
	public void quilt$rebuildIds() {
		SynchronizedInt2ObjectMap.attemptRebuildIds(this.factories);
	}
}
