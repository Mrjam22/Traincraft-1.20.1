/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.mixin;

import java.util.List;
import net.minecraft.network.protocol.game.ServerboundCustomPayloadPacket;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.quiltmc.qsl.registry.impl.sync.server.DelayedPacketsHolder;

@Mixin(ServerPlayer.class)
public class ServerPlayerEntityMixin implements DelayedPacketsHolder {
	@Unique
	private List<ServerboundCustomPayloadPacket> quilt$delayedPackets;

	@Override
	public void quilt$setPacketList(List<ServerboundCustomPayloadPacket> packetList) {
		this.quilt$delayedPackets = packetList;
	}

	@Override
	public List<ServerboundCustomPayloadPacket> quilt$getPacketList() {
		return this.quilt$delayedPackets;
	}
}
