/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.mixin.patch;

import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.quiltmc.qsl.registry.api.StatusEffectsSerializationConstants;

/**
 * Modifies storing of status effect to make it more mod friendly.
 * <p>
 * Minecraft by default serializes status effects as raw registry value, which are not stable at all!
 * Raw registry values may change randomly while adding or removing mods, this may create inconsistencies and corruption.
 * Storing the full identifier fixes this issue. This is the last place where the flattening hasn't taken effect.
 */
@Mixin(BeaconBlockEntity.class)
public class BeaconBlockEntityMixin {
	@Shadow
	@Final
	private static Set<MobEffect> EFFECTS;

	@Shadow
	@Nullable MobEffect primary;

	@Shadow
	@Nullable MobEffect secondary;

	@Inject(method = "writeNbt", at = @At("TAIL"))
	private void quilt$storeIdentifiers(CompoundTag nbt, CallbackInfo ci) {
		if (this.primary != null) {
			nbt.putString(StatusEffectsSerializationConstants.BEACON_PRIMARY_EFFECT_KEY, BuiltInRegistries.MOB_EFFECT.getKey(this.primary).toString());
		}

		if (this.secondary != null) {
			nbt.putString(StatusEffectsSerializationConstants.BEACON_SECONDARY_EFFECT_KEY, BuiltInRegistries.MOB_EFFECT.getKey(this.secondary).toString());
		}
	}

	@Inject(method = "readNbt", at = @At("TAIL"))
	private void quilt$readIdentifiers(CompoundTag compound, CallbackInfo ci) {
		this.primary = this.quilt$readId(StatusEffectsSerializationConstants.BEACON_PRIMARY_EFFECT_KEY, compound, this.primary);
		this.secondary = this.quilt$readId(StatusEffectsSerializationConstants.BEACON_SECONDARY_EFFECT_KEY, compound, this.secondary);
	}

	@Unique
	private @Nullable MobEffect quilt$readId(String nbtKey, CompoundTag compound, MobEffect defaultEffect) {
		if (compound.contains(nbtKey, Tag.TAG_STRING)) {
			var identifier = ResourceLocation.tryParse(compound.getString(nbtKey));

			var quiltEffectStatus = BuiltInRegistries.MOB_EFFECT.get(identifier);

			if (identifier != null && quiltEffectStatus != null && EFFECTS.contains(quiltEffectStatus)) {
				return quiltEffectStatus;
			}
		}

		return defaultEffect;
	}
}
