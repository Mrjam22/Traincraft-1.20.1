/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.impl.sync.client.screen;

import java.util.List;
import java.util.function.DoubleConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractScrollWidget;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.jetbrains.annotations.ApiStatus;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.registry.impl.sync.client.LogBuilder;
import org.quiltmc.qsl.registry.impl.sync.client.LogBuilder.Section;

// TODO - Keep a watch on {@code C_qnehaoor}, it is almost equivalent to this widget
@ApiStatus.Internal
@ClientOnly
public class ScrollableMultiTextWidget extends AbstractScrollWidget {
	private final GridLayout.RowHelper helper;
	private final LayoutSettings headerSettings;
	private final DoubleConsumer scrollUpdater;
	private GridLayout grid;
	private MutableComponent narration = Component.empty();

	public ScrollableMultiTextWidget(Minecraft client, int x, int y, int width, int height, List<LogBuilder.Section> sectionList, double scrollAmount, DoubleConsumer scroll) {
		super(x, y, width, height, Component.empty());

		this.grid = new GridLayout();
		this.grid.rowSpacing(2);
		this.grid.defaultCellSetting().alignHorizontallyLeft();
		this.helper = this.grid.createRowHelper(1);
		this.helper.addChild(SpacerElement.width(width));
		this.headerSettings = this.helper.newCellSettings().alignHorizontallyCenter().paddingHorizontal(32);

		for (var section : sectionList) {
			this.appendHeader(client.font, section.title());
			for (var text : section.entries()) {
				this.appendLine(client.font, text);
			}

			this.appendSpacer(10);
		}

		this.grid.arrangeElements();
		this.scrollUpdater = scroll;
		this.setScrollAmount(scrollAmount);
	}

	@Override
	protected void setScrollAmount(double scrollAmount) {
		super.setScrollAmount(scrollAmount);
		this.scrollUpdater.accept(scrollAmount);
	}

	public void appendLine(Font textRenderer, Component text) {
		this.appendLine(textRenderer, text, 0);
	}

	public void appendLine(Font renderer, Component text, int bottomPadding) {
		this.helper.addChild((new MultiLineTextWidget(text, renderer)).setMaxWidth(this.width), this.helper.newCellSettings().paddingBottom(bottomPadding));
		this.narration.append(text).append("\n");
	}

	public void appendHeader(Font renderer, Component text) {
		this.helper.addChild((new MultiLineTextWidget(text, renderer)).setMaxWidth(this.width - 64).setCentered(true), this.headerSettings);
		this.narration.append(text).append("\n");
	}

	public void appendSpacer(int height) {
		this.helper.addChild(SpacerElement.height(height));
	}

	@Override
	protected int getInnerHeight() {
		return this.grid.getHeight();
	}

	@Override
	protected boolean scrollbarVisible() {
		return this.getInnerHeight() > this.height;
	}

	@Override
	protected double scrollRate() {
		return 9.0D;
	}

	@Override
	protected void renderContents(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		int x = this.getX() + this.innerPadding();
		int y = this.getY() + this.innerPadding();
		int scrollPixels = (int) this.scrollAmount();
		int higherBound = scrollPixels + this.getHeight() + 10;
		int lowerBound = scrollPixels - 10;
		graphics.pose().pushPose();
		graphics.pose().translate(x, y, 0.0D);
		this.grid.visitWidgets((clickableWidget) -> {
			if (clickableWidget.getY() < higherBound && clickableWidget.getY() + clickableWidget.getHeight() > lowerBound) {
				clickableWidget.render(graphics, mouseX, mouseY, delta);
			}
		});
		graphics.pose().popPose();
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput builder) {}
}
