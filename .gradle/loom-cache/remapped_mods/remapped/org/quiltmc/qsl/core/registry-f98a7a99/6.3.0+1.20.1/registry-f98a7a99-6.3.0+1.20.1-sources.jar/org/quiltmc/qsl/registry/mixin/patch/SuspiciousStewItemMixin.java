/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.mixin.patch;

import java.util.function.Consumer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SuspiciousStewItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import org.quiltmc.qsl.registry.api.StatusEffectsSerializationConstants;

/**
 * Modifies storing of status effect to make it more mod friendly.
 * <p>
 * Minecraft by default serializes status effects as raw registry value, which are not stable at all!
 * Raw registry values may change randomly while adding or removing mods, this may create inconsistencies and corruption.
 * Storing the full identifier fixes this issue. This is the last place where the flattening hasn't taken effect.
 */
@Mixin(SuspiciousStewItem.class)
public class SuspiciousStewItemMixin {
	@Unique
	private static final ThreadLocal<MobEffect> quilt$effect = new ThreadLocal<>();

	@Inject(
			method = "addEffectToStew",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/effect/StatusEffect;getRawId(Lnet/minecraft/entity/effect/StatusEffect;)I"),
			locals = LocalCapture.CAPTURE_FAILHARD
	)
	private static void quilt$storeIdentifier(ItemStack stew, MobEffect effect, int duration, CallbackInfo ci,
			CompoundTag unused, ListTag unused2, CompoundTag nbt) {
		nbt.putString(StatusEffectsSerializationConstants.EFFECT_ID_KEY, BuiltInRegistries.MOB_EFFECT.getKey(effect).toString());
	}

	@Inject(
			method = "consumeStatusEffects",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/effect/StatusEffect;byRawId(I)Lnet/minecraft/entity/effect/StatusEffect;"),
			locals = LocalCapture.CAPTURE_FAILHARD
	)
	private static void quilt$readCustomEffect(ItemStack stack, Consumer<MobEffectInstance> consumer, CallbackInfo ci,
			CompoundTag nbtCompound, ListTag nbtList, int i, CompoundTag effectCompound, int j) {
		if (effectCompound.contains(StatusEffectsSerializationConstants.EFFECT_ID_KEY, Tag.TAG_STRING)) {
			var identifier = ResourceLocation.tryParse(effectCompound.getString(StatusEffectsSerializationConstants.EFFECT_ID_KEY));

			if (identifier != null && BuiltInRegistries.MOB_EFFECT.containsKey(identifier)) {
				quilt$effect.set(BuiltInRegistries.MOB_EFFECT.get(identifier));
			} else {
				quilt$effect.remove();
			}
		} else {
			quilt$effect.remove();
		}
	}

	@ModifyArg(
			method = "consumeStatusEffects",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/effect/StatusEffectInstance;<init>(Lnet/minecraft/entity/effect/StatusEffect;I)V"),
			index = 0
	)
	private static MobEffect quilt$setEffect(MobEffect effect) {
		var quiltEffect = quilt$effect.get();

		return quiltEffect != null ? quiltEffect : effect;
	}
}
