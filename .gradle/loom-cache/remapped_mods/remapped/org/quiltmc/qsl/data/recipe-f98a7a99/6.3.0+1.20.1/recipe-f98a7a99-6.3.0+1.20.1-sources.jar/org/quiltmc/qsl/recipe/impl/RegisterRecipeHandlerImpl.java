/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.impl;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.qsl.recipe.api.RecipeLoadingEvents;

final class RegisterRecipeHandlerImpl implements RecipeLoadingEvents.AddRecipesCallback.RecipeHandler {
	private final Map<ResourceLocation, JsonElement> resourceMap;
	private final Map<RecipeType<?>, ImmutableMap.Builder<ResourceLocation, Recipe<?>>> builderMap;
	private final ImmutableMap.Builder<ResourceLocation, Recipe<?>> globalRecipeMapBuilder;
	private final RegistryAccess registryManager;
	int registered = 0;

	RegisterRecipeHandlerImpl(
			Map<ResourceLocation, JsonElement> resourceMap,
			Map<RecipeType<?>, ImmutableMap.Builder<ResourceLocation, Recipe<?>>> builderMap,
			ImmutableMap.Builder<ResourceLocation, Recipe<?>> globalRecipeMapBuilder,
			RegistryAccess registryManager
	) {
		this.resourceMap = resourceMap;
		this.builderMap = builderMap;
		this.globalRecipeMapBuilder = globalRecipeMapBuilder;
		this.registryManager = registryManager;
	}

	private void register(Recipe<?> recipe) {
		ImmutableMap.Builder<ResourceLocation, Recipe<?>> recipeBuilder =
				this.builderMap.computeIfAbsent(recipe.getType(), o -> ImmutableMap.builder());
		recipeBuilder.put(recipe.getId(), recipe);
		this.globalRecipeMapBuilder.put(recipe.getId(), recipe);
		this.registered++;

		if (RecipeManagerImpl.DEBUG_MODE) {
			RecipeManagerImpl.LOGGER.info("Added recipe {} with type {} in register phase.", recipe.getId(), recipe.getType());
		}
	}

	void tryRegister(Recipe<?> recipe) {
		if (!this.resourceMap.containsKey(recipe.getId())) {
			this.register(recipe);
		}
	}

	@Override
	public void register(ResourceLocation id, Function<ResourceLocation, Recipe<?>> factory) {
		// Add the recipe only if nothing already provides the recipe.
		if (!this.resourceMap.containsKey(id)) {
			var recipe = factory.apply(id);

			if (!id.equals(recipe.getId())) {
				throw new IllegalStateException("The recipe " + recipe.getId() + " tried to be registered as " + id);
			}

			this.register(recipe);
		}
	}

	@Override
	public @NotNull RegistryAccess getRegistryManager() {
		return this.registryManager;
	}
}
