/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.mixin;

import com.google.gson.JsonObject;
import net.minecraft.data.recipes.SingleItemRecipeBuilder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.SingleItemRecipe;
import org.spongepowered.asm.mixin.Mixin;
import org.quiltmc.qsl.recipe.api.serializer.QuiltRecipeSerializer;

@Mixin(SingleItemRecipe.Serializer.class)
public abstract class CuttingRecipeSerializerMixin<T extends SingleItemRecipe> implements QuiltRecipeSerializer<T> {
	@Override
	public JsonObject toJson(T recipe) {
		var result = recipe.getResultItem(null);

		return new SingleItemRecipeBuilder.Result(recipe.getId(), this, recipe.getGroup(),
				recipe.getIngredients().get(0), result.getItem(), result.getCount(),
				null, null)
				.serializeRecipe();
	}
}
