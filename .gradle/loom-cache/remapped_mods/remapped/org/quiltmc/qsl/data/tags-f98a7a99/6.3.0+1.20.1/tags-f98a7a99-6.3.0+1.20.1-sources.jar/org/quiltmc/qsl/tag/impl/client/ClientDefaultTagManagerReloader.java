/*
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.tag.impl.client;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.VanillaPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.server.packs.resources.CloseableResourceManager;
import net.minecraft.server.packs.resources.MultiPackResourceManager;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.resource.loader.api.GroupResourcePack.Wrapped;
import org.quiltmc.qsl.resource.loader.impl.ModResourcePackProvider;
import org.quiltmc.qsl.resource.loader.impl.QuiltMultiPackResourceManagerHooks;
import org.quiltmc.qsl.resource.loader.impl.ResourceLoaderImpl;

@ClientOnly
@ApiStatus.Internal
final class ClientDefaultTagManagerReloader extends ClientOnlyTagManagerReloader {
	private static final ResourceLocation ID = new ResourceLocation(ClientQuiltTagsMod.NAMESPACE, "client_default_tags");
	private final PackRepository resourcePackManager;

	ClientDefaultTagManagerReloader() {
		VanillaPackResources defaultPack = Minecraft.getInstance().getVanillaPackResources();

		var pack = ResourceLoaderImpl.buildMinecraftResourcePack(PackType.SERVER_DATA, defaultPack);
		this.resourcePackManager = new PackRepository((profileAdder) -> {
			profileAdder.accept(Pack.readMetaAndCreate("vanilla", pack.getDisplayName(), true, name -> pack,
					PackType.SERVER_DATA, Pack.Position.BOTTOM, PackSource.BUILT_IN
			));
		}, ModResourcePackProvider.SERVER_RESOURCE_PACK_PROVIDER);
	}

	@Override
	public @NotNull ResourceLocation getQuiltId() {
		return ID;
	}

	/**
	 * Returns a resource manager with a modified resource type but with the same resource packs as the client.
	 *
	 * @return the modified resource manager
	 */
	private CloseableResourceManager getServerDataResourceManager() {
		this.resourcePackManager.setSelected(Minecraft.getInstance().getResourcePackRepository().getSelectedIds());
		this.resourcePackManager.reload();
		var manager = new MultiPackResourceManager(PackType.SERVER_DATA, this.resourcePackManager.openAllSelected());
		((QuiltMultiPackResourceManagerHooks) manager).quilt$appendTopPacks();
		return manager;
	}

	@Override
	public CompletableFuture<List<Entry>> load(ResourceManager manager, ProfilerFiller profiler, Executor executor) {
		// First we need to transform the resource manager into one with the type SERVER_DATA,
		// then we can continue as normal.
		return CompletableFuture.supplyAsync(this::getServerDataResourceManager, executor)
				.thenComposeAsync(resourceManager -> super.load(resourceManager, profiler, executor)
								.whenComplete((entries, throwable) -> resourceManager.close()),
						executor
				);
	}

	@Override
	public CompletableFuture<Void> apply(List<Entry> data, ResourceManager manager, ProfilerFiller profiler, Executor executor) {
		return CompletableFuture.runAsync(() -> {
			data.forEach(entry -> entry.manager().setFallbackSerializedTags(entry.serializedTags()));
		}, executor);
	}
}
