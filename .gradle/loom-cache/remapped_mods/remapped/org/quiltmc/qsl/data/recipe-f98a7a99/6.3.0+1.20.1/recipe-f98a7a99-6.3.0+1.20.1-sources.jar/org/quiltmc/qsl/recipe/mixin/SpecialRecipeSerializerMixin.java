/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.mixin;

import java.util.Objects;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.SimpleCraftingRecipeSerializer;
import com.google.gson.JsonObject;
import org.spongepowered.asm.mixin.Mixin;
import org.quiltmc.qsl.recipe.api.serializer.QuiltRecipeSerializer;

@Mixin(SimpleCraftingRecipeSerializer.class)
public abstract class SpecialRecipeSerializerMixin<T extends Recipe<?>> implements QuiltRecipeSerializer<T> {
	@Override
	public JsonObject toJson(T recipe) {
		var json = new JsonObject();
		json.addProperty("type", Objects.requireNonNull(BuiltInRegistries.RECIPE_SERIALIZER.getKey(this)).toString());
		return json;
	}
}
