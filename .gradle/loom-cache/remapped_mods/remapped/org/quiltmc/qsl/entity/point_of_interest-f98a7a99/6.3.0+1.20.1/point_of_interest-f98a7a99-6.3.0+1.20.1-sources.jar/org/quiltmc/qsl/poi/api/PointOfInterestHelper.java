/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.poi.api;

import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.village.poi.PoiRecord;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import com.google.common.collect.ImmutableSet;
import org.quiltmc.qsl.poi.impl.PointOfInterestTypeExtensions;

/**
 * This class provides utilities to create a {@link PoiType}.
 * <p>
 * A point of interest is typically used by villagers to specify their workstation blocks, meeting zones and homes.
 * Points of interest are also used by bees to specify where their bee hive is and nether portals to find existing portals.
 */
public final class PointOfInterestHelper {
	/**
	 * Creates and registers a {@link PoiType}.
	 *
	 * @param id             The id of this {@link PoiType}
	 * @param ticketCount    the max amount of tickets available to be checked out from searches
	 * @param searchDistance the distance in blocks from the {@link PoiRecord} a {@link net.minecraft.world.entity.Mob} can be before considering it reached
	 * @param blocks         all blocks where a {@link PoiRecord} of this type will be present. Will apply to all of the {@link Block}'s {@link BlockState}s
	 * @return a new {@link ResourceKey} for the {@link PoiType}
	 */
	public static ResourceKey<PoiType> register(ResourceLocation id, int ticketCount, int searchDistance, Block... blocks) {
		final ImmutableSet.Builder<BlockState> builder = ImmutableSet.builder();

		for (Block block : blocks) {
			builder.addAll(block.getStateDefinition().getPossibleStates());
		}

		return register(id, ticketCount, searchDistance, builder);
	}

	/**
	 * Creates and registers a {@link PoiType}.
	 *
	 * @param id             the id of this {@link PoiType}
	 * @param ticketCount    the max amount of tickets available to be checked out from searches
	 * @param searchDistance the distance in blocks from the {@link PoiRecord} a {@link net.minecraft.world.entity.Mob} can be before considering it reached
	 * @param states         all {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 * @return a new {@link ResourceKey} for the {@link PoiType}
	 */
	public static ResourceKey<PoiType> register(ResourceLocation id, int ticketCount, int searchDistance, Iterable<BlockState> states) {
		final ImmutableSet.Builder<BlockState> builder = ImmutableSet.builder();

		return register(id, ticketCount, searchDistance, builder.addAll(states));
	}

	/**
	 * Creates and registers a {@link PoiType}.
	 *
	 * @param id             the id of this {@link PoiType}
	 * @param ticketCount    the max amount of tickets available to be checked out from searches
	 * @param searchDistance the distance in blocks from the {@link PoiRecord} a {@link net.minecraft.world.entity.Mob} can be before considering it reached
	 * @param states         all {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 * @return a new {@link ResourceKey} for the {@link PoiType}
	 */
	public static ResourceKey<PoiType> register(ResourceLocation id, int ticketCount, int searchDistance, Set<BlockState> states) {
		return register(id, new PoiType(ImmutableSet.copyOf(states), ticketCount, searchDistance));
	}

	/**
	 * Creates and registers a {@link PoiType}.
	 *
	 * @param id             the id of this {@link PoiType}
	 * @param ticketCount    the max amount of tickets available to be checked out from searches
	 * @param searchDistance the distance in blocks from the {@link PoiRecord} a {@link net.minecraft.world.entity.Mob} can be before considering it reached
	 * @param states         all {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 * @return a new {@link ResourceKey} for the {@link PoiType}
	 */
	public static ResourceKey<PoiType> register(ResourceLocation id, int ticketCount, int searchDistance, ImmutableSet.Builder<BlockState> states) {
		return register(id, new PoiType(states.build(), ticketCount, searchDistance));
	}

	/**
	 * Registers a {@link PoiType}.
	 *
	 * @param id      the {@link ResourceLocation} to register this {@link PoiType} under
	 * @param poiType the {@link PoiType} to register
	 * @return the {@link ResourceKey} for the {@link PoiType}
	 */
	public static ResourceKey<PoiType> register(ResourceLocation id, PoiType poiType) {
		var key = ResourceKey.create(Registries.POINT_OF_INTEREST_TYPE, id);
		Registry.register(BuiltInRegistries.POINT_OF_INTEREST_TYPE, key, poiType);
		poiType.matchingStates().forEach(state -> {
			Holder<PoiType> replaced = PoiTypes.TYPE_BY_STATE.put(state, BuiltInRegistries.POINT_OF_INTEREST_TYPE.getHolderOrThrow(key));
			if (replaced != null) {
				throw Util.pauseInIde(new IllegalStateException(String.format("%s is defined in too many tags", state)));
			}
		});
		return key;
	}

	/**
	 * Allows adding {@link Block}s to a {@link PoiType} after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param blocks all additional {@link Block}s where a {@link PoiRecord} of this type will be present. Will apply to all of the {@link Block}'s {@link BlockState}s
	 */
	public static void addBlocks(ResourceKey<PoiType> key, Block... blocks) {
		BuiltInRegistries.POINT_OF_INTEREST_TYPE.getOptional(key).ifPresent(type -> ((PointOfInterestTypeExtensions) (Object) type).quilt$addBlocks(key, Arrays.asList(blocks)));
	}

	/**
	 * Allows adding {@link Block}s to a {@link PoiType} after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param blocks all additional {@link Block}s where a {@link PoiRecord} of this type will be present. Will apply to all of the {@link Block}'s {@link BlockState}s
	 */
	public static void addBlocks(ResourceKey<PoiType> key, Collection<Block> blocks) {
		BuiltInRegistries.POINT_OF_INTEREST_TYPE.getOptional(key).ifPresent(type -> ((PointOfInterestTypeExtensions) (Object) type).quilt$addBlocks(key, blocks));
	}

	/**
	 * Allows adding {@link Block}s to a {@link PoiType} after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param states all additional {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 */
	public static void addBlockStates(ResourceKey<PoiType> key, BlockState... states) {
		BuiltInRegistries.POINT_OF_INTEREST_TYPE.getOptional(key).ifPresent(type -> ((PointOfInterestTypeExtensions) (Object) type).quilt$addBlockStates(key, Arrays.asList(states)));
	}

	/**
	 * Allows adding {@link Block}s to a {@link PoiType} after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param states all additional {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 */
	public static void addBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states) {
		BuiltInRegistries.POINT_OF_INTEREST_TYPE.getOptional(key).ifPresent(type -> ((PointOfInterestTypeExtensions) (Object) type).quilt$addBlockStates(key, states));
	}

	/**
	 * Allows replacing the {@link PoiType}s {@link Block}s after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param blocks all blocks where a {@link PoiRecord} of this type will be present.
	 *               Will apply to all of the {@link Block}'s {@link BlockState}s
	 */
	public static void setBlocks(ResourceKey<PoiType> key, Block... blocks) {
		PointOfInterestHelper.setBlocks(key, Arrays.asList(blocks));
	}

	/**
	 * Allows replacing the {@link PoiType}s {@link Block}s after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param blocks all blocks where a {@link PoiRecord} of this type will be present.
	 *               Will apply to all of the {@link Block}'s {@link BlockState}s
	 */
	public static void setBlocks(ResourceKey<PoiType> key, Collection<Block> blocks) {
		BuiltInRegistries.POINT_OF_INTEREST_TYPE.getOptional(key).ifPresent(type -> ((PointOfInterestTypeExtensions) (Object) type).quilt$setBlocks(key, blocks));
	}

	/**
	 * Allows replacing the {@link PoiType}s {@link BlockState}s after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param states all {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 */
	public static void setBlockStates(ResourceKey<PoiType> key, BlockState... states) {
		PointOfInterestHelper.setBlockStates(key, Arrays.asList(states));
	}

	/**
	 * Allows replacing the {@link PoiType}s {@link BlockState}s after construction.
	 *
	 * @param key    the {@link ResourceKey} of the {@link PoiType} to add these blocks to
	 * @param states all {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 */
	public static void setBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states) {
		BuiltInRegistries.POINT_OF_INTEREST_TYPE.getOptional(key).ifPresent(type -> ((PointOfInterestTypeExtensions) (Object) type).quilt$setBlockStates(key, states));
	}
}
