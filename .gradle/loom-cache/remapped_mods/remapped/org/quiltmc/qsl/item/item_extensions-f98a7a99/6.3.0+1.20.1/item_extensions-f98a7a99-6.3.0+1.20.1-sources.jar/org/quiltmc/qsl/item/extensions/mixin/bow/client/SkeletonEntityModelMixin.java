/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.item.extensions.mixin.bow.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.client.model.SkeletonModel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.quiltmc.qsl.item.extensions.api.bow.BowExtensions;

@Mixin(SkeletonModel.class)
public abstract class SkeletonEntityModelMixin {
	// Allows Skeletons to visually shoot custom bows by returning true
	@Redirect(
			method = "animateModel(Lnet/minecraft/entity/mob/MobEntity;FFF)V",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;isOf(Lnet/minecraft/item/Item;)Z")
	)
	private boolean animateModel(ItemStack heldItemStack, Item item) {
		return heldItemStack.getItem() instanceof BowExtensions;
	}

	// Allows Skeletons to visually shoot custom bows by returning true
	@Redirect(
			method = "setAngles(Lnet/minecraft/entity/mob/MobEntity;FFFFF)V",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;isOf(Lnet/minecraft/item/Item;)Z")
	)
	private boolean setAngles(ItemStack heldItemStack, Item item) {
		return heldItemStack.getItem() instanceof BowExtensions;
	}
}
