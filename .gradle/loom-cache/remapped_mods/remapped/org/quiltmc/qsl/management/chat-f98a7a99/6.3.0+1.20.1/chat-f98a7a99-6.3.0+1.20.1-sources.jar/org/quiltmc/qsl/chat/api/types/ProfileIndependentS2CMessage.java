/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.chat.api.types;

import java.util.EnumSet;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundDisguisedChatPacket;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.qsl.chat.api.QuiltMessageType;
import org.quiltmc.qsl.chat.impl.InternalMessageTypesFactory;
import org.quiltmc.qsl.chat.mixin.client.ClientPlayNetworkHandlerAccessor;

/**
 * A wrapper around a "profile independent" message. These are usually created as a result of commands like {@link net.minecraft.server.commands.MsgCommand}.
 */
public class ProfileIndependentS2CMessage extends AbstractChatMessage<ClientboundDisguisedChatPacket> {
	private final Component message;
	private final ChatType.Bound messageType;

	public ProfileIndependentS2CMessage(Player player, boolean isClient, ClientboundDisguisedChatPacket packet) {
		this(
				player,
				isClient,
				packet.message(),
				packet.chatType().resolve(player.level().registryAccess()).orElseGet(() -> {
					if (player instanceof LocalPlayer clientPlayerEntity) {
						((ClientPlayNetworkHandlerAccessor) clientPlayerEntity.connection).getConnection().disconnect(Component.translatable("multiplayer.disconnect.invalid_packet"));
					}

					return null;
				})
		);
	}

	public ProfileIndependentS2CMessage(Player player, boolean isClient, Component message, ChatType.Bound messageType) {
		super(player, isClient);
		this.message = message;
		this.messageType = messageType;
	}

	@Override
	public @NotNull EnumSet<QuiltMessageType> getTypes() {
		return InternalMessageTypesFactory.s2cType(QuiltMessageType.PROFILE_INDEPENDENT, this.isClient);
	}

	@Override
	public @NotNull ClientboundDisguisedChatPacket serialized() {
		return new ClientboundDisguisedChatPacket(this.message, this.messageType.toNetwork(this.player.level().registryAccess()));
	}

	@Contract(pure = true)
	public Component getMessage() {
		return this.message;
	}

	@Contract(pure = true)
	public ChatType.Bound getMessageType() {
		return this.messageType;
	}

	@Contract(value = "_ -> new", pure = true)
	public ProfileIndependentS2CMessage withMessage(Component message) {
		return new ProfileIndependentS2CMessage(this.player, this.isClient, message, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ProfileIndependentS2CMessage withMessageType(ChatType.Bound messageType) {
		return new ProfileIndependentS2CMessage(this.player, this.isClient, this.message, messageType);
	}

	@Override
	public String toString() {
		return "ProfileIndependentS2CMessage{" + "message=" + this.message +
				", messageType=" + this.messageType +
				", player=" + this.player +
				", isClient=" + this.isClient +
				'}';
	}
}
