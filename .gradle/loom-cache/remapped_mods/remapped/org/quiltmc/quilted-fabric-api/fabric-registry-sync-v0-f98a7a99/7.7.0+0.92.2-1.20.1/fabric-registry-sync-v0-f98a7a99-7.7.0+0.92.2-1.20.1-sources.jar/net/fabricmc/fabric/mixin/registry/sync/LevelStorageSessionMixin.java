/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.registry.sync;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.registry.sync.QuiltedRegistrySync;
import net.fabricmc.fabric.impl.registry.sync.RegistryMapSerializer;
import net.fabricmc.fabric.impl.registry.sync.RemapException;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.WorldData;

/**
 * Ok, here's some documentation for this long-lost Mixin.
 *
 * <p>So, this has tortured me quite a bit "why do we need this mixin"?
 * The answer is quite scary!
 *
 * <p>This code actually has been written in 2016, for the first attempt at Fabric, during the 1.11 snapshot cycle.
 * For the most observant, 1.11 would tickle your hear, it is before the 1.13 update, <b>before the flattening</b>.
 *
 * <p>So it makes sense to save the raw identifiers to identifiers map with the world, why wouldn't it?
 * Except not in a post-1.13 world.
 *
 * <p>I investigated and found the only remnant of the pre-1.13 era: status effects.
 * Those damn status effects still are saved to disk using raw identifiers, making this needed.
 */
@Mixin(LevelStorageSource.LevelStorageAccess.class)
public class LevelStorageSessionMixin {
	@Unique
	private static final int FABRIC_ID_REGISTRY_BACKUPS = 3;
	@Unique
	private static final Logger FABRIC_LOGGER = LoggerFactory.getLogger("FabricRegistrySync");
	@Unique
	private Map<ResourceLocation, Object2IntMap<ResourceLocation>> fabric_lastSavedRegistryMap = null;

	@Shadow
	@Final
	private LevelStorageSource.LevelDirectory directory;

	@Unique
	private boolean fabric_readIdMapFile(File file) throws IOException, RemapException {
		FABRIC_LOGGER.debug("Reading registry data from " + file.toString());

		if (file.exists()) {
			FileInputStream fileInputStream = new FileInputStream(file);
			CompoundTag tag = NbtIo.readCompressed(fileInputStream);
			fileInputStream.close();

			if (tag != null) {
				var fabric_activeRegistryMap = RegistryMapSerializer.fromNbt(tag);
				QuiltedRegistrySync.applyStatusEffectsRegistryMap(fabric_activeRegistryMap);
				return true;
			}
		}

		return false;
	}

	@Unique
	private File fabric_getWorldIdMapFile(int i) {
		return new File(new File(directory.path().toFile(), "data"), "fabricRegistry" + ".dat" + (i == 0 ? "" : ("." + i)));
	}

	@Unique
	private void fabric_saveRegistryData() {
		FABRIC_LOGGER.debug("Starting registry save");
		Map<ResourceLocation, Object2IntMap<ResourceLocation>> newMap = QuiltedRegistrySync.createStatusEffectsRegistryMap();

		if (newMap == null) {
			FABRIC_LOGGER.debug("Not saving empty registry data");
			return;
		}

		if (!newMap.equals(fabric_lastSavedRegistryMap)) {
			for (int i = FABRIC_ID_REGISTRY_BACKUPS - 1; i >= 0; i--) {
				File file = fabric_getWorldIdMapFile(i);

				if (file.exists()) {
					if (i == FABRIC_ID_REGISTRY_BACKUPS - 1) {
						file.delete();
					} else {
						File target = fabric_getWorldIdMapFile(i + 1);
						file.renameTo(target);
					}
				}
			}

			try {
				File file = fabric_getWorldIdMapFile(0);
				File parentFile = file.getParentFile();

				if (!parentFile.exists()) {
					if (!parentFile.mkdirs()) {
						FABRIC_LOGGER.warn("[fabric-registry-sync] Could not create directory " + parentFile + "!");
					}
				}

				FABRIC_LOGGER.debug("Saving registry data to " + file);
				var fileOutputStream = new FileOutputStream(file);
				NbtIo.writeCompressed(RegistryMapSerializer.toNbt(newMap), fileOutputStream);
				fileOutputStream.close();
			} catch (IOException e) {
				FABRIC_LOGGER.warn("[fabric-registry-sync] Failed to save registry file!", e);
			}

			fabric_lastSavedRegistryMap = newMap;
		}
	}

	@Inject(method = "backupLevelDataFile(Lnet/minecraft/registry/DynamicRegistryManager;Lnet/minecraft/world/SaveProperties;Lnet/minecraft/nbt/NbtCompound;)V", at = @At("HEAD"))
	public void saveWorld(RegistryAccess registryTracker, WorldData saveProperties, CompoundTag compoundTag, CallbackInfo info) {
		if (!Files.exists(directory.path())) {
			return;
		}

		fabric_saveRegistryData();
	}

	// TODO: stop double save on client?
	// TODO: Figure out what asie meant by this ^
	@Inject(method = "readLevelProperties", at = @At("HEAD"))
	public void readWorldProperties(CallbackInfoReturnable<WorldData> callbackInfo) {
		// Load
		for (int i = 0; i < FABRIC_ID_REGISTRY_BACKUPS; i++) {
			FABRIC_LOGGER.trace("[fabric-registry-sync] Loading Fabric registry [file " + (i + 1) + "/" + (FABRIC_ID_REGISTRY_BACKUPS + 1) + "]");

			try {
				if (fabric_readIdMapFile(fabric_getWorldIdMapFile(i))) {
					FABRIC_LOGGER.info("[fabric-registry-sync] Loaded registry data [file " + (i + 1) + "/" + (FABRIC_ID_REGISTRY_BACKUPS + 1) + "]");
					return;
				}
			} catch (FileNotFoundException e) {
				// pass
			} catch (IOException e) {
				if (i >= FABRIC_ID_REGISTRY_BACKUPS - 1) {
					throw new RuntimeException(e);
				} else {
					FABRIC_LOGGER.warn("Reading registry file failed!", e);
				}
			} catch (RemapException e) {
				throw new RuntimeException("Remapping world failed!", e);
			}
		}

		// If not returned (not present), try saving the registry data
		fabric_saveRegistryData();
	}
}
