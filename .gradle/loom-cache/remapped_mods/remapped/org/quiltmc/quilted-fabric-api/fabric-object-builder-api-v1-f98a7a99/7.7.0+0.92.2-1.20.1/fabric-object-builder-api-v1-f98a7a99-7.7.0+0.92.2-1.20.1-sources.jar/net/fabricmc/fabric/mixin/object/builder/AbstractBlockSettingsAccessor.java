/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.object.builder;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BlockBehaviour.Properties.class)
public interface AbstractBlockSettingsAccessor {
	/* GETTERS */
	@Deprecated
	@Accessor
	float getHardness();

	@Deprecated
	@Accessor
	float getResistance();

	@Deprecated
	@Accessor
	boolean getCollidable();

	@Deprecated
	@Accessor
	boolean getRandomTicks();

	@Deprecated
	@Accessor("luminance")
	ToIntFunction<BlockState> getLuminance();

	@Deprecated
	@Accessor
	Function<BlockState, MapColor> getMapColorProvider();

	@Deprecated
	@Accessor
	SoundType getSoundGroup();

	@Deprecated
	@Accessor
	float getSlipperiness();

	@Deprecated
	@Accessor
	float getVelocityMultiplier();

	@Deprecated
	@Accessor
	float getJumpVelocityMultiplier();

	@Accessor
	boolean getDynamicBounds();

	@Deprecated
	@Accessor
	boolean getOpaque();

	@Deprecated
	@Accessor
	boolean getIsAir();

	@Deprecated
	@Accessor
	boolean isToolRequired();

	@Deprecated
	@Accessor
	BlockBehaviour.StateArgumentPredicate<EntityType<?>> getAllowsSpawningPredicate();

	@Deprecated
	@Accessor
	BlockBehaviour.StatePredicate getSolidBlockPredicate();

	@Deprecated
	@Accessor
	BlockBehaviour.StatePredicate getSuffocationPredicate();

	@Deprecated
	@Accessor
	BlockBehaviour.StatePredicate getBlockVisionPredicate();

	@Deprecated
	@Accessor
	BlockBehaviour.StatePredicate getPostProcessPredicate();

	@Deprecated
	@Accessor
	BlockBehaviour.StatePredicate getEmissiveLightingPredicate();

	@Deprecated
	@Accessor
	Optional<BlockBehaviour.OffsetFunction> getOffsetter();

	@Deprecated
	@Accessor
	ResourceLocation getLootTableId();

	@Deprecated
	@Accessor
	boolean getBlockBreakParticles();

	@Deprecated
	@Accessor
	FeatureFlagSet getRequiredFeatures();

	@Accessor
	boolean getBurnable();

	@Accessor
	boolean getLiquid();

	@Accessor
	boolean getForceNotSolid();

	@Accessor
	boolean getForceSolid();

	@Accessor
	PushReaction getPistonBehavior();

	@Accessor
	NoteBlockInstrument getInstrument();

	@Accessor
	boolean getReplaceable();

	/* SETTERS */
	@Accessor
	void setCollidable(boolean collidable);

	@Deprecated
	@Accessor
	void setRandomTicks(boolean ticksRandomly);

	@Accessor
	void setMapColorProvider(Function<BlockState, MapColor> mapColorProvider);

	@Accessor
	void setDynamicBounds(boolean dynamicBounds);

	@Deprecated
	@Accessor
	void setOpaque(boolean opaque);

	@Deprecated
	@Accessor
	void setIsAir(boolean isAir);

	@Accessor
	void setLootTableId(ResourceLocation lootTableId);

	@Deprecated
	@Accessor
	void setToolRequired(boolean toolRequired);

	@Accessor
	void setBlockBreakParticles(boolean blockBreakParticles);

	@Accessor
	void setRequiredFeatures(FeatureFlagSet requiredFeatures);

	@Accessor
	void setOffsetter(Optional<BlockBehaviour.OffsetFunction> offsetter);

	@Accessor
	void setBurnable(boolean burnable);

	@Accessor
	void setLiquid(boolean liquid);

	@Accessor
	void setForceNotSolid(boolean forceNotSolid);

	@Accessor
	void setForceSolid(boolean forceSolid);

	@Accessor
	void setReplaceable(boolean replaceable);
}
