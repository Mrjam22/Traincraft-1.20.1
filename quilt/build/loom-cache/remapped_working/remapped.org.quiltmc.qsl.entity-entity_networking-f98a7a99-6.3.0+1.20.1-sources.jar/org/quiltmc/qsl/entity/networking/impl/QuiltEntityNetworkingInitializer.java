/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.entity.networking.impl;

import com.mojang.serialization.Lifecycle;
import net.minecraft.core.MappedRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.ApiStatus;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
import org.quiltmc.qsl.registry.api.sync.RegistrySynchronization;

@ApiStatus.Internal
public class QuiltEntityNetworkingInitializer implements ModInitializer {
	public static final ResourceLocation EXTENDED_SPAWN_PACKET_ID = new ResourceLocation("quilt", "extended_entity_spawn_packet");

	public static final MappedRegistry<EntityDataSerializer<?>> TRACKED_DATA_HANDLER_REGISTRY = new MappedRegistry<>(
			ResourceKey.createRegistryKey(new ResourceLocation("quilt", "tracked_data_handlers")), Lifecycle.stable(), false
	);

	private static boolean markForSync = true;

	public static <T> EntityDataSerializer<T> register(ResourceLocation identifier, EntityDataSerializer<T> handler) {
		Registry.register(QuiltEntityNetworkingInitializer.TRACKED_DATA_HANDLER_REGISTRY, identifier, handler);

		if (markForSync) {
			RegistrySynchronization.markForSync(QuiltEntityNetworkingInitializer.TRACKED_DATA_HANDLER_REGISTRY);
			markForSync = false;
		}

		return handler;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onInitialize(ModContainer mod) {
		Registry.register(((Registry<Registry<EntityDataSerializer<?>>>) BuiltInRegistries.REGISTRY), TRACKED_DATA_HANDLER_REGISTRY.key().location(), TRACKED_DATA_HANDLER_REGISTRY);
	}
}
