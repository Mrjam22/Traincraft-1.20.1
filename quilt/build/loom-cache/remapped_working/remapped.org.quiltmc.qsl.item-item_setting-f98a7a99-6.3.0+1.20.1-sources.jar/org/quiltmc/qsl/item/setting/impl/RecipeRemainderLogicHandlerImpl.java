/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.item.setting.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.core.NonNullList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLocation;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLogicHandler;

@ApiStatus.Internal
public final class RecipeRemainderLogicHandlerImpl implements RecipeRemainderLogicHandler {
	public static final Map<ResourceLocation, RecipeRemainderLocation> LOCATIONS = new HashMap<>();
	public static final Set<RecipeRemainderLocation> DEFAULT_LOCATIONS = new HashSet<>();

	/**
	 * @return {@code true} if returning the item to the inventory was successful, or {@code false} if additional handling for the remainder is needed
	 */
	@Contract(mutates = "param1, param2")
	private static boolean tryReturnItemToInventory(ItemStack remainder, NonNullList<ItemStack> inventory, int index) {
		ItemStack leftovers = inventory.get(index);
		if (leftovers.isEmpty()) {
			inventory.set(index, remainder);
			return true;
		}

		return tryMergeStacks(leftovers, remainder);
	}

	/**
	 * @return {@code true} if returning the item to the slot was successful, or {@code false} if additional handling for the remainder is needed
	 */
	@Contract(mutates = "param1, param2")
	private static boolean tryReturnItemToSlot(ItemStack remainder, Slot slot) {
		ItemStack leftovers = slot.getItem();
		if (leftovers.isEmpty()) {
			slot.set(remainder);
			return true;
		}

		return tryMergeStacks(leftovers, remainder);
	}

	/**
	 * @return {@code true} if the remainder stack was fully merged into the base stack, or {@code false} otherwise
	 */
	@Contract(mutates = "param1, param2")
	private static boolean tryMergeStacks(ItemStack base, ItemStack remainder) {
		if (remainder.isEmpty()) {
			return true;
		} else if (!ItemStack.isSameItemSameTags(base, remainder)) {
			return false;
		}

		int toTake = Math.min(base.getMaxStackSize() - base.getCount(), remainder.getCount());
		remainder.shrink(toTake);
		base.grow(toTake);
		return remainder.isEmpty();
	}

	@Contract(mutates = "param1")
	private static ItemStack decrementWithRemainder(ItemStack original, int amount, @Nullable Recipe<?> recipe, RecipeRemainderLocation location) {
		if (original.isEmpty()) {
			return ItemStack.EMPTY;
		}

		ItemStack remainder = RecipeRemainderLogicHandler.getRemainder(original, recipe, location);

		original.shrink(amount);

		return remainder;
	}

	@Contract(mutates = "param1, param5, param7")
	public static void handleRemainderForNonPlayerCraft(ItemStack input, int amount, @Nullable Recipe<?> recipe, RecipeRemainderLocation location, NonNullList<ItemStack> inventory, int index, Consumer<ItemStack> failure) {
		ItemStack remainder = decrementWithRemainder(input, amount, recipe, location);

		if (!tryReturnItemToInventory(remainder, inventory, index)) {
			failure.accept(remainder);
		}
	}

	@Contract(mutates = "param1, param5")
	public static void handleRemainderForScreenHandler(Slot slot, int amount, @Nullable Recipe<?> recipe, RecipeRemainderLocation location, Player player) {
		ItemStack remainder = decrementWithRemainder(slot.getItem(), amount, recipe, location);

		if (!tryReturnItemToSlot(remainder, slot)) {
			player.getInventory().placeItemBackInInventory(remainder);
		}

		slot.setChanged();
	}
}
