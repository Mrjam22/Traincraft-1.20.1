/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.item.setting.mixin.recipe_remainder;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.ItemCombinerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.SmithingMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.SmithingRecipe;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLocation;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLogicHandler;

@Mixin(SmithingMenu.class)
public abstract class SmithingScreenHandlerMixin extends ItemCombinerMenu {
	@Shadow
	private @Nullable SmithingRecipe currentRecipe;

	@Shadow
	public abstract void createResult();

	public SmithingScreenHandlerMixin(@Nullable MenuType<?> screenHandlerType, int i, Inventory playerInventory, ContainerLevelAccess screenHandlerContext) {
		super(screenHandlerType, i, playerInventory, screenHandlerContext);
	}

	@Redirect(method = "onTakeOutput", at = @At(value = "INVOKE", target = "Lnet/minecraft/screen/SmithingScreenHandler;decrementStack(I)V"))
	private void applyRecipeRemainderToIngredient(SmithingMenu instance, int slot) {
		RecipeRemainderLogicHandler.handleRemainderForScreenHandler(
				this.getSlot(slot),
				1,
				this.currentRecipe,
				switch (slot) {
					case SmithingMenu.TEMPLATE_SLOT -> RecipeRemainderLocation.SMITHING_TEMPLATE;
					case SmithingMenu.BASE_SLOT -> RecipeRemainderLocation.SMITHING_BASE;
					case SmithingMenu.ADDITIONAL_SLOT -> RecipeRemainderLocation.SMITHING_INGREDIENT;
					default -> throw new IllegalStateException("Unexpected value: " + slot);
				},
				this.player
		);
	}

	@Inject(method = "onTakeOutput", at = @At("RETURN"))
	public void refreshOutput(Player player, ItemStack stack, CallbackInfo ci) {
		this.createResult();
	}
}
