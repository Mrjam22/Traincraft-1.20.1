/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.testing.impl.game.command;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.structures.NbtToSnbt;
import net.minecraft.gametest.framework.StructureUtils;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.StructureBlockEntity;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public final class QuiltTestCommand {
	public static int executeExport(CommandSourceStack source) {
		BlockPos currentPos = BlockPos.containing(source.getPosition());
		ServerLevel world = source.getLevel();
		BlockPos nearestStructureBlockPos = StructureUtils.findNearestStructureBlock(currentPos, 15, world);

		if (nearestStructureBlockPos == null) {
			source.sendFailure(Component.literal("Couldn't find any structure block within 15 blocks radius."));
			return 0;
		} else {
			var structureBlock = (StructureBlockEntity) world.getBlockEntity(nearestStructureBlockPos);
			return executeExport(source, structureBlock.getStructureName());
		}
	}

	public static int executeExport(CommandSourceStack source, String structure) {
		Path directoryPath = Paths.get(StructureUtils.testStructuresDir);
		var structureId = new ResourceLocation(structure);

		Path structurePath = source.getLevel().getStructureManager().getPathToGeneratedStructure(structureId, ".nbt");
		Path exportedPath = NbtToSnbt.convertStructure(CachedOutput.NO_CACHE, structurePath, structure.replace(':', '/'), directoryPath);

		if (exportedPath == null) {
			source.sendFailure(Component.literal("Failed to export " + structurePath));
			source.sendFailure(Component.literal("Hint: you need to save the structure first with the structure block."));
			return 1;
		} else {
			try {
				Files.createDirectories(exportedPath.getParent());
			} catch (IOException error) {
				source.sendFailure(Component.literal("Could not create folder " + exportedPath.getParent() + ", a stack trace is available in the logs."));
				error.printStackTrace();
				return 1;
			}

			source.sendSystemMessage(Component.literal("Exported ")
					.append(Component.literal(structure).withStyle(ChatFormatting.GOLD))
					.append(" to ")
					.append(Component.literal(exportedPath.toAbsolutePath().toString()).withStyle(ChatFormatting.GOLD))
					.append(" [")
					.append(Component.literal("Open Directory")
							.withStyle(style -> style.withColor(ChatFormatting.GREEN)
									.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, directoryPath.toAbsolutePath().toString()))
									.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click to open.")))
							)
					)
					.append("]")
			);
			return 0;
		}
	}
}
