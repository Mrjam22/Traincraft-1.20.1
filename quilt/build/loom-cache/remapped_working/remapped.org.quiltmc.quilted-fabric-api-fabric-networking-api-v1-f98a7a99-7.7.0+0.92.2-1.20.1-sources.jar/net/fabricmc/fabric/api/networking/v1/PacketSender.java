/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.networking.v1;

import io.netty.channel.ChannelFutureListener;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.impl.networking.GenericFutureListenerHolder;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.resources.ResourceLocation;

/**
 * Represents something that supports sending packets to channels.
 *
 * @see PacketByteBufs
 * @deprecated Use Quilt Networking's {@link org.quiltmc.qsl.networking.api.PacketSender} instead.
 */
@Deprecated
public interface PacketSender extends org.quiltmc.qsl.networking.api.PacketSender {
	/**
	 * Sends a packet.
	 * @param packet the packet
	 */
	default <T extends FabricPacket> void sendPacket(T packet) {
		FriendlyByteBuf buf = PacketByteBufs.create();
		packet.write(buf);
		sendPacket(packet.getType().getId(), buf);
	}

	/**
	 * Sends a packet.
	 *
	 * @param packet the packet
	 * @param callback an optional callback to execute after the packet is sent, may be {@code null}. The callback may also accept a {@link ChannelFutureListener}.
	 */
	void sendPacket(Packet<?> packet, @Nullable GenericFutureListener<? extends Future<? super Void>> callback);

	/**
	 * Sends a packet.
	 *
	 * @param packet the packet
	 * @param callback an optional callback to execute after the packet is sent, may be {@code null}. The callback may also accept a {@link ChannelFutureListener}.
	 */
	default <T extends FabricPacket> void sendPacket(T packet, @Nullable GenericFutureListener<? extends Future<? super Void>> callback) {
		FriendlyByteBuf buf = PacketByteBufs.create();
		packet.write(buf);
		sendPacket(packet.getType().getId(), buf, callback);
	}

	/**
	 * Sends a packet.
	 *
	 * @param packet the packet
	 * @param callback an optional callback to execute after the packet is sent, may be {@code null}. The callback may also accept a {@link ChannelFutureListener}.
	 */
	default <T extends FabricPacket> void sendPacket(T packet, @Nullable PacketSendListener callback) {
		FriendlyByteBuf buf = PacketByteBufs.create();
		packet.write(buf);
		sendPacket(packet.getType().getId(), buf, callback);
	}

	/**
	 * Sends a packet to a channel.
	 *
	 * @param channel  the id of the channel
	 * @param buf the content of the packet
	 * @param callback an optional callback to execute after the packet is sent, may be {@code null}
	 */
	// the generic future listener can accept ChannelFutureListener
	default void sendPacket(ResourceLocation channel, FriendlyByteBuf buf, @Nullable GenericFutureListener<? extends Future<? super Void>> callback) {
		sendPacket(channel, buf, GenericFutureListenerHolder.create(callback));
	}
}
