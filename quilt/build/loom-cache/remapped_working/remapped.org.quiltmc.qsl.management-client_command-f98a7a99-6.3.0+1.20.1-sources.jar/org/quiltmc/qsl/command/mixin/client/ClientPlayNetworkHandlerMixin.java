/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.command.mixin.client;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.ClientRegistryLayer;
import net.minecraft.client.multiplayer.ClientSuggestionProvider;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.LayeredRegistryAccess;
import net.minecraft.network.protocol.game.ClientboundCommandsPacket;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.world.flag.FeatureFlagSet;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.quiltmc.qsl.command.impl.client.ClientCommandInternals;

@Mixin(ClientPacketListener.class)
abstract class ClientPlayNetworkHandlerMixin {
	@Shadow
	private CommandDispatcher<SharedSuggestionProvider> commandDispatcher;

	@Shadow
	@Final
	private ClientSuggestionProvider commandSource;

	@Shadow
	private LayeredRegistryAccess<ClientRegistryLayer> clientRegistryManager;

	@Shadow
	@Final
	private Minecraft client;

	@Shadow
	private FeatureFlagSet enabledFlags;

	@SuppressWarnings({"unchecked", "rawtypes"})
	@Inject(method = "onGameJoin", at = @At("RETURN"))
	private void onGameJoin(ClientboundLoginPacket packet, CallbackInfo ci) {
		ClientCommandInternals.updateCommands(CommandBuildContext.configurable(this.clientRegistryManager.compositeAccess(), this.enabledFlags),
				(CommandDispatcher) this.commandDispatcher, this.commandSource,
				this.client.hasSingleplayerServer() ? Commands.CommandSelection.INTEGRATED
						: Commands.CommandSelection.DEDICATED
		);
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	@Inject(method = "onCommandTreeUpdate", at = @At("RETURN"))
	private void onOnCommandTree(ClientboundCommandsPacket packet, CallbackInfo info) {
		ClientCommandInternals.updateCommands(null,
				(CommandDispatcher) this.commandDispatcher, this.commandSource,
				this.client.hasSingleplayerServer() ? Commands.CommandSelection.INTEGRATED
						: Commands.CommandSelection.DEDICATED
		);
	}

	@Inject(method = "sendCommand", at = @At("HEAD"), cancellable = true)
	private void onSendCommand(String command, CallbackInfoReturnable<Boolean> cir) {
		if (ClientCommandInternals.executeCommand(command, true)) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "sendChatCommand", at = @At("HEAD"), cancellable = true)
	private void onSendCommand(String command, CallbackInfo ci) {
		if (ClientCommandInternals.executeCommand(command, true)) {
			ci.cancel();
		}
	}
}
