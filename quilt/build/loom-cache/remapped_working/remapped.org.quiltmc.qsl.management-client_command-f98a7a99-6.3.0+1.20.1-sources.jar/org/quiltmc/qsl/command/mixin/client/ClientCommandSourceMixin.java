/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.command.mixin.client;

import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientSuggestionProvider;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.quiltmc.qsl.command.api.client.QuiltClientCommandSource;

@Mixin(ClientSuggestionProvider.class)
abstract class ClientCommandSourceMixin implements QuiltClientCommandSource {
	@Shadow
	@Final
	private Minecraft client;

	@Unique
	private final Map<String, Object> meta = new Object2ObjectOpenHashMap<>();

	@Override
	public void sendFeedback(Component message) {
		this.client.gui.getChat().addMessage(message);
		this.client.getNarrator().sayNow(message);
	}

	@Override
	public void sendError(Component message) {
		this.sendFeedback(message.copy().withStyle(ChatFormatting.RED));
	}

	@Override
	public Minecraft getClient() {
		return this.client;
	}

	@Override
	public LocalPlayer getPlayer() {
		return this.client.player;
	}

	@Override
	public ClientLevel getWorld() {
		return this.client.level;
	}

	@Override
	public Object getMeta(String key) {
		return this.meta.get(key);
	}

	@Override
	public void setMeta(String key, Object value) {
		this.meta.put(key, value);
	}
}
