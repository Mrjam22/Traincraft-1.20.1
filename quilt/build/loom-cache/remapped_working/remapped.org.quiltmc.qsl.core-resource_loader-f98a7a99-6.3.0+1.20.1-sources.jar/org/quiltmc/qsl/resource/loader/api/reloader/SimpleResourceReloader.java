/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.api.reloader;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;

/**
 * A simplified version of the "resource reloader" interface, hiding the peculiarities of the API.
 * <p>
 * In essence, there are two stages:
 *
 * <ul>
 *     <li>{@linkplain #load(ResourceManager, ProfilerFiller, Executor)}: create an instance of your data object
 * containing all loaded and processed information,
 *     <li>{@linkplain #apply(Object, ResourceManager, ProfilerFiller, Executor)}: apply the information from the data object
 * to the game instance.
 * </ul>
 *
 * <p>
 * The load stage should be self-contained as it can run on any thread!
 * However, the apply stage is guaranteed to run on the game thread.
 * <p>
 * For a fully synchronous alternative, consider using {@link SimpleSynchronousResourceReloader}.
 *
 * @param <T> the type for the intermediate reloading state
 */
public interface SimpleResourceReloader<T> extends IdentifiableResourceReloader {
	@Override
	default CompletableFuture<Void> reload(PreparableReloadListener.PreparationBarrier helper, ResourceManager manager,
			ProfilerFiller loadProfiler, ProfilerFiller applyProfiler,
			Executor loadExecutor, Executor applyExecutor) {
		return this.load(manager, loadProfiler, loadExecutor).thenCompose(helper::wait)
				.thenCompose(o -> this.apply(o, manager, applyProfiler, applyExecutor));
	}

	/**
	 * Asynchronously process and load resource-based data. The code
	 * must be thread-safe and not modify game state!
	 *
	 * @param manager  the resource manager used during reloading
	 * @param profiler the profiler which may be used for this stage
	 * @param executor the executor which should be used for this stage
	 * @return a CompletableFuture representing the "data loading" stage
	 */
	CompletableFuture<T> load(ResourceManager manager, ProfilerFiller profiler, Executor executor);

	/**
	 * Synchronously apply loaded data to the game state.
	 *
	 * @param manager  the resource manager used during reloading
	 * @param profiler the profiler which may be used for this stage
	 * @param executor the executor which should be used for this stage
	 * @return a CompletableFuture representing the "data applying" stage
	 */
	CompletableFuture<Void> apply(T data, ResourceManager manager, ProfilerFiller profiler, Executor executor);
}
