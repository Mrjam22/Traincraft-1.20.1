/*
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.api;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
import net.minecraft.server.packs.resources.IoSupplier;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnmodifiableView;

/**
 * Represents a group resource pack, which holds multiple resource packs as one.
 * <p>
 * The possible use cases are:
 * <ul>
 *   <li>bundling multiple resource packs as one to reduce pollution of the user's UI</li>
 *   <li>replacing the default resource pack with a combination of the default one and all mods' resource packs</li>
 *   <li>etc.</li>
 * </ul>
 */
public abstract class GroupResourcePack implements PackResources {
	protected final PackType type;
	protected final List<? extends PackResources> packs;
	protected final Map<String, List<PackResources>> namespacedPacks = new Object2ObjectOpenHashMap<>();
	private boolean builtin;

	public GroupResourcePack(@NotNull PackType type, @NotNull List<? extends PackResources> packs) {
		this.type = type;
		this.packs = packs;
		this.recompute();
	}

	/**
	 * Gets an unmodifiable list of the resource packs stored in this group resourced pack.
	 *
	 * @return the resource packs
	 */
	public @UnmodifiableView List<? extends PackResources> getPacks() {
		return Collections.unmodifiableList(this.packs);
	}

	/**
	 * Gets an unmodifiable list of the resource packs stored in this group resource pack
	 * which contain the given {@code namespace}.
	 *
	 * @param namespace the namespace the packs must contain
	 * @return the list of the matching resource packs
	 */
	public @UnmodifiableView List<? extends PackResources> getPacks(String namespace) {
		return Collections.unmodifiableList(this.namespacedPacks.get(namespace));
	}

	/**
	 * Gets a flattened stream of resource packs in this group resource pack.
	 *
	 * @return the flattened stream of resource packs
	 */
	public @NotNull Stream<? extends PackResources> streamPacks() {
		return this.packs.stream().mapMulti((pack, consumer) -> {
			if (pack instanceof GroupResourcePack grouped) {
				grouped.streamPacks().forEach(consumer);
			} else {
				consumer.accept(pack);
			}
		});
	}

	/**
	 * Recomputes some cached data in case the resource pack list changes.
	 */
	public void recompute() {
		this.namespacedPacks.clear();
		this.packs.forEach(pack -> pack.getNamespaces(this.type)
				.forEach(namespace -> this.namespacedPacks.computeIfAbsent(namespace, value -> new ArrayList<>())
						.add(pack)));

		this.builtin = this.packs.stream().allMatch(PackResources::isBuiltin);
	}

	@Override
	public @Nullable IoSupplier<InputStream> getResource(PackType type, ResourceLocation id) {
		var packs = this.namespacedPacks.get(id.getNamespace());

		if (packs != null) {
			// Iterating backwards as higher-priority packs are placed at the end.
			for (int i = packs.size() - 1; i >= 0; i--) {
				PackResources pack = packs.get(i);
				var supplier = pack.getResource(type, id);

				if (supplier != null) {
					return supplier;
				}
			}
		}

		return null;
	}

	@Override
	public void listResources(PackType type, String namespace, String startingPath,
			PackResources.ResourceOutput consumer) {
		var packs = this.namespacedPacks.get(namespace);

		// Iterating backwards as higher-priority packs are placed at the end.
		for (var pack : packs) {
			pack.listResources(type, namespace, startingPath, consumer);
		}
	}

	@Override
	public Set<String> getNamespaces(PackType type) {
		return this.namespacedPacks.keySet();
	}

	public @NotNull String getFullName() {
		return this.packId() + " (" + this.packs.stream().map(PackResources::packId).collect(Collectors.joining(", ")) + ")";
	}

	@Override
	public boolean isBuiltin() {
		return this.builtin;
	}

	@Override
	public void close() {
		this.packs.forEach(PackResources::close);
	}

	/**
	 * Represents a group resource pack which wraps a "base" resource pack.
	 */
	public static class Wrapped extends GroupResourcePack {
		private final PackResources basePack;

		/**
		 * Constructs a new instance of a group resource pack wrapping a base resource pack.
		 *
		 * @param type         the resource type of this resource pack
		 * @param basePack     the base resource pack
		 * @param packs        the additional packs
		 * @param basePriority {@code true} if the base resource pack has priority over the additional packs, or {@code false} otherwise.
		 *                     Ignored if the base resource pack is already present in the list
		 */
		public Wrapped(@NotNull PackType type, @NotNull PackResources basePack, @NotNull List<PackResources> packs, boolean basePriority) {
			super(type, addToPacksIfNeeded(basePack, packs, basePriority));
			this.basePack = basePack;
		}

		private static List<PackResources> addToPacksIfNeeded(PackResources basePack, List<PackResources> packs,
				boolean basePriority) {
			if (!packs.contains(basePack)) {
				if (basePriority) {
					packs.add(basePack);
				} else {
					packs.add(0, basePack);
				}
			}

			return packs;
		}

		@Override
		public @Nullable IoSupplier<InputStream> getRootResource(String... path) {
			return this.basePack.getRootResource(path);
		}

		@Override
		public <T> @Nullable T getMetadataSection(MetadataSectionSerializer<T> metaReader) throws IOException {
			return this.basePack.getMetadataSection(metaReader);
		}

		@Override
		public String packId() {
			return this.basePack.packId();
		}

		@Override
		public @NotNull Component getDisplayName() {
			return this.basePack.getDisplayName();
		}

		@Override
		public @NotNull String getFullName() {
			return this.packId() + " (" + this.packs.stream().filter(pack -> pack != this.basePack)
					.map(PackResources::packId).collect(Collectors.joining(", ")) + ")";
		}
	}
}
