/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.api.reloader;

import net.minecraft.resources.ResourceLocation;

/**
 * This class contains default keys for various Minecraft resource reloaders.
 *
 * @see IdentifiableResourceReloader
 */
public final class ResourceReloaderKeys {
	/**
	 * Represents the application phase before Vanilla resource reloaders are invoked.
	 * <p>
	 * No resource reloaders are assigned to this identifier.
	 *
	 * @see org.quiltmc.qsl.resource.loader.api.ResourceLoader#addReloaderOrdering(ResourceLocation, ResourceLocation)
	 */
	public static final ResourceLocation BEFORE_VANILLA = new ResourceLocation("quilt", "before_vanilla");
	/**
	 * Represents the application phase after Vanilla resource reloaders are invoked.
	 * <p>
	 * No resource reloaders are assigned to this identifier.
	 *
	 * @see org.quiltmc.qsl.resource.loader.api.ResourceLoader#addReloaderOrdering(ResourceLocation, ResourceLocation)
	 */
	public static final ResourceLocation AFTER_VANILLA = new ResourceLocation("quilt", "after_vanilla");

	/**
	 * Keys for various client resource reloaders.
	 */
	public static final class Client {
		public static final ResourceLocation BLOCK_ENTITY_RENDERERS = id("block_entity_renderers");
		public static final ResourceLocation BLOCK_RENDER_MANAGER = id("block_render_manager");
		public static final ResourceLocation BUILTIN_ITEM_MODELS = id("builtin_item_models");
		public static final ResourceLocation ENTITY_MODELS = id("entity_models");
		public static final ResourceLocation ENTITY_RENDERERS = id("entity_renderers");
		public static final ResourceLocation FOLIAGE_COLORMAP = id("foliage_colormap");
		public static final ResourceLocation FONTS = id("fonts");
		public static final ResourceLocation GRASS_COLORMAP = id("grass_colormap");
		public static final ResourceLocation ITEM_RENDERER = id("item_renderer");
		public static final ResourceLocation LANGUAGES = id("languages");
		public static final ResourceLocation MODELS = id("models");
		public static final ResourceLocation PAINTINGS = id("paintings");
		public static final ResourceLocation PARTICLES = id("particles");
		public static final ResourceLocation SHADERS = id("shaders");
		public static final ResourceLocation SOUNDS = id("sounds");
		public static final ResourceLocation SPLASH_TEXTS = id("splash_texts");
		public static final ResourceLocation SPRITE_ATLASES = id("sprite_atlases");
		public static final ResourceLocation STATUS_EFFECTS = id("status_effects");
		public static final ResourceLocation TEXTURES = id("textures");

		private Client() {
		}
	}

	/**
	 * Keys for various server resource reloaders.
	 */
	public static final class Server {
		public static final ResourceLocation ADVANCEMENTS = id("advancements");
		public static final ResourceLocation FUNCTIONS = id("functions");
		public static final ResourceLocation LOOT_TABLES = id("loot_tables");
		public static final ResourceLocation RECIPES = id("recipes");
		public static final ResourceLocation TAGS = id("tags");

		private Server() {
		}
	}

	private ResourceReloaderKeys() {
	}

	private static ResourceLocation id(String path) {
		return new ResourceLocation(ResourceLocation.DEFAULT_NAMESPACE, path);
	}
}
