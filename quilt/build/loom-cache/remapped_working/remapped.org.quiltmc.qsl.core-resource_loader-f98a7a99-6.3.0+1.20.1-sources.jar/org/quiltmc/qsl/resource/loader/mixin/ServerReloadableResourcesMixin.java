/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.mixin;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.commands.Commands;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.ReloadableServerResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.flag.FeatureFlagSet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.quiltmc.qsl.resource.loader.impl.QuiltMultiPackResourceManagerHooks;
import org.quiltmc.qsl.resource.loader.impl.ResourceLoaderImpl;

@Mixin(ReloadableServerResources.class)
public class ServerReloadableResourcesMixin {
	@Inject(method = "getReloaders", at = @At("RETURN"), cancellable = true)
	private void onGetResourceReloaders(CallbackInfoReturnable<List<PreparableReloadListener>> cir) {
		// Re-inject resource reloaders server-side.
		// It is currently unknown why ReloadableResourceManager#reload isn't called anymore.
		var list = new ArrayList<>(cir.getReturnValue());
		ResourceLoaderImpl.sort(PackType.SERVER_DATA, list);
		cir.setReturnValue(list);
	}

	@Inject(method = "loadResources", at = @At("HEAD"))
	private static void onLoadResources(ResourceManager resources, RegistryAccess.Frozen registry, FeatureFlagSet featureFlagBitSet,
			Commands.CommandSelection environment, int level, Executor prepareExecutor, Executor applyExecutor,
			CallbackInfoReturnable<CompletableFuture<ReloadableServerResources>> cir) {
		if (resources instanceof QuiltMultiPackResourceManagerHooks hooks) {
			hooks.quilt$appendTopPacks();
		}
	}
}
