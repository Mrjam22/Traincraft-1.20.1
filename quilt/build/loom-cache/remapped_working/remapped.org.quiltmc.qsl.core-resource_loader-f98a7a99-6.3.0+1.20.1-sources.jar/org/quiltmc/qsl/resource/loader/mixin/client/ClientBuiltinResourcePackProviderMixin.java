/*
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.mixin.client;

import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.client.resources.ClientPackSource;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.BuiltInPackSource;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.resource.loader.impl.ModResourcePackProvider;
import org.quiltmc.qsl.resource.loader.impl.ResourceLoaderImpl;

@ClientOnly
@Mixin(ClientPackSource.class)
public class ClientBuiltinResourcePackProviderMixin {
	@Shadow
	@Final
	private static Map<String, Component> BUILTIN_PACK_DISPLAY_NAMES;

	@ModifyArg(
			method = "createBuiltinResourcePackProfile(Ljava/lang/String;Lnet/minecraft/resource/pack/ResourcePackProfile$ResourcePackFactory;Lnet/minecraft/text/Text;)Lnet/minecraft/resource/pack/ResourcePackProfile;",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/resource/pack/ResourcePackProfile;of(Ljava/lang/String;Lnet/minecraft/text/Text;ZLnet/minecraft/resource/pack/ResourcePackProfile$ResourcePackFactory;Lnet/minecraft/resource/ResourceType;Lnet/minecraft/resource/pack/ResourcePackProfile$InsertionPosition;Lnet/minecraft/resource/pack/ResourcePackSource;)Lnet/minecraft/resource/pack/ResourcePackProfile;"
			),
			index = 3
	)
	private Pack.ResourcesSupplier onCreateBuiltinResourcePackProfile(String name, Component displayName, boolean alwaysEnabled,
			Pack.ResourcesSupplier factory, PackType type, Pack.Position insertionPosition,
			PackSource source) {
		if (BUILTIN_PACK_DISPLAY_NAMES.containsKey(name)) {
			return n -> ResourceLoaderImpl.buildVanillaBuiltinResourcePack(factory.open(n), PackType.CLIENT_RESOURCES, name);
		}

		return factory;
	}

	// Synthetic method createBuiltinResourcePackProfile(ResourcePack)ResourcePackProfile
	// Using an injector to wrap the previous return value.
	@Inject(
			method = "method_45855(Lnet/minecraft/resource/pack/ResourcePack;Ljava/lang/String;)Lnet/minecraft/resource/pack/ResourcePack;",
			at = @At("RETURN"),
			cancellable = true
	)
	private static void onPackGet(PackResources pack, String name, CallbackInfoReturnable<PackResources> cir) {
		cir.setReturnValue(ResourceLoaderImpl.buildMinecraftResourcePack(PackType.CLIENT_RESOURCES, cir.getReturnValue()));
	}

	@ClientOnly
	@Mixin(BuiltInPackSource.class)
	public static class Parent {
		@SuppressWarnings("ConstantConditions")
		@Inject(method = "registerAdditionalPacks", at = @At("RETURN"))
		private void addBuiltinResourcePacks(Consumer<Pack> profileAdder, CallbackInfo ci) {
			// Register built-in resource packs after vanilla built-in resource packs are registered.
			if (((Object) this) instanceof ClientPackSource) {
				ModResourcePackProvider.CLIENT_RESOURCE_PACK_PROVIDER.loadPacks(profileAdder);
			}
		}
	}
}
