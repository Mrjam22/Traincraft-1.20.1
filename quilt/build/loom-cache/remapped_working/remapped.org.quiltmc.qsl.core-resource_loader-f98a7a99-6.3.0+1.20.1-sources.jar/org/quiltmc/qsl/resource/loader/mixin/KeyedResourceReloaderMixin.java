/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.mixin;

import java.util.Locale;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.ServerAdvancementManager;
import net.minecraft.server.ServerFunctionLibrary;
import net.minecraft.tags.TagManager;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.storage.loot.LootDataManager;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.quiltmc.qsl.resource.loader.api.reloader.IdentifiableResourceReloader;
import org.quiltmc.qsl.resource.loader.api.reloader.ResourceReloaderKeys;

@Mixin({
		RecipeManager.class, ServerAdvancementManager.class, ServerFunctionLibrary.class,
		LootDataManager.class, TagManager.class
})
public abstract class KeyedResourceReloaderMixin implements IdentifiableResourceReloader {
	@Unique
	private ResourceLocation quilt$id;

	@Override
	@SuppressWarnings({"ConstantConditions"})
	public @NotNull ResourceLocation getQuiltId() {
		if (this.quilt$id == null) {
			Object self = this;

			if (self instanceof RecipeManager) {
				this.quilt$id = ResourceReloaderKeys.Server.RECIPES;
			} else if (self instanceof ServerAdvancementManager) {
				this.quilt$id = ResourceReloaderKeys.Server.ADVANCEMENTS;
			} else if (self instanceof ServerFunctionLibrary) {
				this.quilt$id = ResourceReloaderKeys.Server.FUNCTIONS;
			} else if (self instanceof LootDataManager) {
				this.quilt$id = ResourceReloaderKeys.Server.LOOT_TABLES;
			} else if (self instanceof TagManager) {
				this.quilt$id = ResourceReloaderKeys.Server.TAGS;
			} else {
				this.quilt$id = new ResourceLocation("private/" + self.getClass().getSimpleName().toLowerCase(Locale.ROOT));
			}
		}

		return this.quilt$id;
	}
}
