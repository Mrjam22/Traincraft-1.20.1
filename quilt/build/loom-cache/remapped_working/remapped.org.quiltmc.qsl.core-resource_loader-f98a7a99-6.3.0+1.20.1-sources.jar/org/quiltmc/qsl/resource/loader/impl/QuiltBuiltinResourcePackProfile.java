/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.impl;

import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackCompatibility;
import net.minecraft.server.packs.repository.PackSource;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.quiltmc.qsl.resource.loader.api.ResourcePackActivationType;

@ApiStatus.Internal
public final class QuiltBuiltinResourcePackProfile extends Pack {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final PackResources pack;

	static @Nullable QuiltBuiltinResourcePackProfile of(ModNioResourcePack pack) {
		Info info = readPackInfo(pack.packId(), name -> pack);

		if (info == null) {
			LOGGER.warn("Couldn't find pack meta for pack {}.", pack.packId());
			return null;
		}

		return new QuiltBuiltinResourcePackProfile(pack, info);
	}

	private QuiltBuiltinResourcePackProfile(ModNioResourcePack pack, Info info) {
		super(
				pack.packId(),
				pack.getActivationType() == ResourcePackActivationType.ALWAYS_ENABLED,
				name -> pack,
				pack.getDisplayName(),
				info,
				info.compatibility(pack.type),
				Pack.Position.TOP,
				false,
				new BuiltinResourcePackSource(pack)
		);
		this.pack = pack;
	}

	@Override
	public PackCompatibility getCompatibility() {
		// This is to ease multi-version mods whose built-in packs actually work across versions.
		return PackCompatibility.COMPATIBLE;
	}

	@Override
	public @NotNull ResourcePackActivationType getActivationType() {
		return this.pack.getActivationType();
	}

	/**
	 * Represents a built-in resource pack source.
	 * Similar to {@link PackSource#BUILT_IN} but specifies the mod name too.
	 */
	public static class BuiltinResourcePackSource implements PackSource {
		private static final Component SOURCE_BUILTIN_TEXT = Component.translatable("pack.source.builtin");
		private final ModNioResourcePack pack;
		private final Component text;
		private final Component tooltip;

		BuiltinResourcePackSource(ModNioResourcePack pack) {
			String modName = pack.modInfo.name();

			if (modName == null) {
				modName = pack.modInfo.id();
			}

			this.pack = pack;
			this.text = SOURCE_BUILTIN_TEXT;
			this.tooltip = Component.translatable("options.generic_value", SOURCE_BUILTIN_TEXT, modName);
		}

		@Override
		public Component decorate(Component description) {
			return Component.translatable("pack.nameAndSource", description, this.text).withStyle(ChatFormatting.GRAY);
		}

		@Override
		public boolean shouldAddAutomatically() {
			return this.pack.getActivationType().isEnabledByDefault();
		}

		public Component getTooltip() {
			return this.tooltip;
		}
	}
}
