/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.worldgen.biome.impl.modification;

import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.structure.Structure;
import org.jetbrains.annotations.ApiStatus;
import org.quiltmc.qsl.worldgen.biome.api.BiomeSelectionContext;

@ApiStatus.Internal
public class BiomeSelectionContextImpl implements BiomeSelectionContext {
	private final RegistryAccess dynamicRegistries;
	private final ResourceKey<Biome> key;
	private final Biome biome;
	private final Holder<Biome> entry;

	public BiomeSelectionContextImpl(RegistryAccess dynamicRegistries, ResourceKey<Biome> key, Biome biome) {
		this.dynamicRegistries = dynamicRegistries;
		this.key = key;
		this.biome = biome;
		this.entry = dynamicRegistries.registryOrThrow(Registries.BIOME).getHolderOrThrow(this.key);
	}

	@Override
	public ResourceKey<Biome> getBiomeKey() {
		return this.key;
	}

	@Override
	public Biome getBiome() {
		return this.biome;
	}

	@Override
	public Holder<Biome> getBiomeHolder() {
		return this.entry;
	}

	@Override
	public Optional<ResourceKey<ConfiguredFeature<?, ?>>> getFeatureKey(ConfiguredFeature<?, ?> configuredFeature) {
		Registry<ConfiguredFeature<?, ?>> registry = this.dynamicRegistries.registryOrThrow(Registries.CONFIGURED_FEATURE);
		return registry.getResourceKey(configuredFeature);
	}

	@Override
	public Optional<ResourceKey<PlacedFeature>> getPlacedFeatureKey(PlacedFeature placedFeature) {
		Registry<PlacedFeature> registry = this.dynamicRegistries.registryOrThrow(Registries.PLACED_FEATURE);
		return registry.getResourceKey(placedFeature);
	}

	@Override
	public boolean validForStructure(ResourceKey<Structure> key) {
		Structure instance = this.dynamicRegistries.registryOrThrow(Registries.STRUCTURE).get(key);

		if (instance == null) {
			return false;
		}

		return instance.biomes().contains(this.getBiomeHolder());
	}

	@Override
	public Optional<ResourceKey<Structure>> getStructureKey(Structure configuredStructure) {
		Registry<Structure> registry = this.dynamicRegistries.registryOrThrow(Registries.STRUCTURE);
		return registry.getResourceKey(configuredStructure);
	}

	@Override
	public boolean canGenerateIn(ResourceKey<LevelStem> dimensionKey) {
		LevelStem dimension = this.dynamicRegistries.registryOrThrow(Registries.LEVEL_STEM).get(dimensionKey);

		if (dimension == null) {
			return false;
		}

		return dimension.generator().getBiomeSource().possibleBiomes().stream().anyMatch(entry -> entry.value() == this.biome);
	}

	@Override
	public boolean isIn(TagKey<Biome> tag) {
		Registry<Biome> biomeRegistry = this.dynamicRegistries.registryOrThrow(Registries.BIOME);
		return biomeRegistry.getHolderOrThrow(this.getBiomeKey()).is(tag);
	}

	@Override
	public <T> boolean doesRegistryEntryExist(ResourceKey<? extends Registry<? extends T>> registryKey, ResourceKey<T> entryKey) {
		return this.dynamicRegistries.registry(registryKey).map(registry -> registry.containsKey(entryKey)).orElse(false);
	}
}
